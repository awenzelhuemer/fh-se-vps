﻿namespace VPS.Wator.Improved3
{
    public enum AnimalType
    {
        Shark,
        Fish
    }
}